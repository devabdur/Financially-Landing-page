(function ($) {
  'use strict';

  jQuery(document).ready(function ($) {
    // code
  });

  jQuery(window).on('load', function () {
    // code
  });
})(jQuery);
